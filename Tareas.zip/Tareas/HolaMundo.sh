#!/bin/bash

#soy un comentario xd 
echo "Holaaa mundo xd"

