#!/bin/bash

#se define una variable
HOLA="Soy la variable"

echo -n "este script te dice : "
echo ${HOLA}
