#!/bin/bash

# definicion de variables 

una_variable=666
mi_nombre="stWebs"
nombres="cristofer abad islas ramirez"
bool=true

echo "veamos las variables"
echo "un numero del diablo: ${una_variable}"
echo "un nombre: ${mi_nombre}"
echo "mi nombre completo: ${nombres}"

echo "has invocado el script pasandome ${0} esta ${1}"
